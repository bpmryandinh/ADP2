public class Customer extends User{
    private String address;
    private String phone;

    public void addToCart(int productid, String userid){
    }

    public void removeFromCart(int productid, String userId){
    }
}
