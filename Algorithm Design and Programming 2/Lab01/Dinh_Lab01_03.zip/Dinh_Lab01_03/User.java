public class User {
    private String userid;
    private String password;
    private String name;
    private String email;

    public boolean authenticate (String username, String password){
        return false;
    }

    public void register (String userid, String password, String name, String email){
    }
}
