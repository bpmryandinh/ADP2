public class Administrator extends User{

    public void addProduct(String name, double price, int quantity){
    }

    public void modifyProduct(int productid, String name, double price, int quantity){
    }

    public void deleteProduct(int productid){
    }

    public void listUsers(){
    }
}
