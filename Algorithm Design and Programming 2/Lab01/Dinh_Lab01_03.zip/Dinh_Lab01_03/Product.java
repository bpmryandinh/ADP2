public class Product {
    private int productid;
    private String name;
    private double price;
    private int quantity;
}
