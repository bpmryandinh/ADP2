import java.util.ArrayList;

public class Cart extends Customer{
    private int cartid;
    private String userid;
    private ArrayList<Product> products;

    public void list(){
    }
}
